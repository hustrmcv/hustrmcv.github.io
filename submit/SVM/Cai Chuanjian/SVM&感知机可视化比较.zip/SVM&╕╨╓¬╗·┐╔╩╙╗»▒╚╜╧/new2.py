import numpy as np
import random
import matplotlib.pyplot as plt
from sklearn import svm


X = np.array([[1,3],[2,5],[3,8],[2,6],[3,1],[4,1],[6,2],[7,3]])
Y = [1,1,1,1,-1,-1,-1,-1]

# fit the model
clf = svm.SVC(kernel='linear')
clf.fit(X, Y)

# get the separating hyperplane
w = clf.coef_[0]
a = -w[0] / w[1]
xx = np.linspace(1, 10)
yy = a * xx - (clf.intercept_[0]) / w[1]

# plot the parallels to the separating hyperplane that pass through the
# support vectors
b = clf.support_vectors_[0]
yy_down = a * xx + (b[1] - a * b[0])
b = clf.support_vectors_[-1]
yy_up = a * xx + (b[1] - a * b[0])


plt.plot(xx, yy, 'k-',label='svm')
plt.plot(xx, yy_down, 'k--',label='svm_para2')
plt.plot(xx, yy_up, 'k-.',label='svm_para1')


###########################################################
# 符号函数
def sign(v):
    if v > 0:
        return 1
    else:
        return -1
# 训练函数
def training():
    train_data1 = [[1, 3, 1], [2, 5, 1], [3, 8, 1], [2, 6, 1]]  # 正样本
    train_data2 = [[3, 1, -1], [4, 1, -1], [6, 2, -1], [7, 3, -1]]  # 负样本
    train_datas = train_data1 + train_data2  # 样本集

    weight = [0, 0]  # 权重
    bias = 0  # 偏置量
    learning_rate = 0.5  # 学习速率

    train_num =  200                              #int(input("train num: "))  # 迭代次数

    for i in range(train_num):
        train = random.choice(train_datas)
        [x1, x2, y] = train
        predict = sign(weight[0] * x1 + weight[1] * x2 + bias)  # 输出
        print("train data: x: (%d, %d) y: %d  ==> predict: %d" % (x1, x2, y, predict))
        if y * predict <= 0:  # 判断误分类点
            weight[0] = weight[0] + learning_rate * y * x1  # 更新权重
            weight[1] = weight[1] + learning_rate * y * x2
            bias = bias + learning_rate * y  # 更新偏置量
            print("update weight and bias: "),
            print(weight[0], weight[1], bias)

    print("stop training: "),
    print(weight[0], weight[1], bias)

    return weight, bias
	
        
def vis():
    w,b=training()
    
    k=w[0]
    m=w[1]
    
    p=np.linspace(1,10)
    
    q=(-k*p-b)/m
    
    x	=	[1,2,3,2] 
    y	=	[3,5,8,6]

    x1  =   [3,4,6,7]
    y1  =   [1,1,2,3]

    
    plt.plot(p,q,label='pct',linewidth=3.5)
    

    plt.scatter(x,y, label='1', color='b', s=25, marker="s")
    plt.scatter(x1,y1, label='-1', color='k', s=25, marker="s")

    plt.xlabel('x') 
    plt.ylabel('y') 
    plt.title('Comparison of svm & perceptron') 
    plt.legend() 
    plt.show()


vis()



